<?php include('templates/header.php');?>
<form id="frmPayment" action="payment.php" method="post"> 
    <section class="showcase">
      <div class="container">
        <div class="pb-2 mt-4 mb-2 border-bottom">
          <h2>Authorize.Net Payment Gateway Integration using PHP</h2>
        </div>
        <div class="row align-items-center">
           <div class="form-group col-md-12">
            <label for="inputEmail4">Amount</label>
            <input type="text" class="form-control" id="amount" name="amount" placeholder="amount" value="1.00" readonly="readonly">
          </div>
      </div>
        <div class="row align-items-center">
           <div class="form-group col-md-6">
            <label for="inputEmail4">First Name</label>
            <input type="text" class="form-control" id="first-name" name="first_name" placeholder="First Name" required="">
          </div>

          <div class="form-group col-md-6">
            <label for="inputEmail4">Last Name</label>
            <input type="text" class="form-control" id="last-name" name="last_name" placeholder="Last Name" required="">
          </div>

      </div>
        <div class="row align-items-center">  
          <div class="form-group col-md-12">
            <label for="inputEmail4">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required="">
          </div>
        </div>
        <div class="row align-items-center">  
          <div class="form-group col-md-12">
            <label for="inputEmail4">Card Number</label>
            <input type="text" class="form-control" maxlength="18" id="card_number" name="card_number" placeholder="4111111111111111" autocomplete="off" required="">
          </div>
        </div>

        <div class="row align-items-center">  
          <div class="form-group col-md-4">
            <label for="inputEmail4">Expiry Month</label>
            <select name="card_exp_month" id="month" class="form-control" required="">
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="form-group col-md-4">
            <label for="inputEmail4">Expiry Year</label>
            <select name="card_exp_year" id="year" class="form-control" required="">
                <?php
                echo $firstYear = (int)date('Y');
                $lastYear = $firstYear + 10;
                for($i=$firstYear;$i<=$lastYear;$i++)
                {
                    echo '<option value='.$i.'>'.$i.'</option>';
                }
                ?>
            </select>
        </div>
        <div class="form-group col-md-4">
            <label for="inputEmail4">CVC</label>
            <input type="text" name="card_cvc" maxlength="3" placeholder="CVC" class="form-control" autocomplete="off" required="">
        </div>
          </div>
          <div class="row justify-content-start">
              <div class="col">
                <button type="submit" name="pay_now" class="btn btn-primary float-right btn-payment">Pay Now</button>
              </div>
            </div>
        </div>
    </div>
    </section>
</form>
<br>

<section class="showcase">
      <div class="container">
        <h3>Test Card </h3>
        <table cellspacing="5" cellpadding="5" width="100%" border="1">
            <tr>
                <td>4111111111111111</td>
                <td>Visa</td>
            </tr>
            
            <tr>
                <td>5424000000000015</td>
                <td>Mastercard</td>
            </tr>
            
            <tr>
                <td>370000000000002</td>
                <td>American Express</td>
            </tr>
            
            <tr>
                <td>6011000000000012</td>
                <td>Discover</td>
            </tr>
            
            <tr>
                <td>38000000000006</td>
                <td>Diners Club/ Carte Blanche</td>
            </tr>
            
            <tr>
                <td>3088000000000017</td>
                <td>JCB</td>
            </tr>
            
        </table>
    </div>
</section>

<?php include('templates/footer.php');?>