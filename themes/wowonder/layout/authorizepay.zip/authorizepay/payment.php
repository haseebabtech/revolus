<?php
require_once "./config.php";
include('./Order.php');
$payObj = new Order();
$reponseType = "";
$message = "";

$postData = $_POST;

if(!empty($postData['card_number']) && !empty($postData['card_exp_month']) && !empty($postData['card_exp_year']) && !empty($postData['card_cvc'])){ 

    require_once './AuthorizeNetPayment.php';
    $authorizeNetObj = new AuthorizeNetPayment();
    
    $response = $authorizeNetObj->chargeCreditCard($postData);

    // set customer data
    $authorizeNetObj->customerData($postData);

    if ($response != null) {
        $transResponse = $response->getTransactionResponse();
        
        if (($transResponse != null) && ($transResponse->getResponseCode()=="1")) {
            $authCode = $transResponse->getAuthCode();
            $paymentResponse = $transResponse->getMessages()[0]->getDescription();
            $reponseType = "success";
            $message = "<div class='alert alert-success'>Your Payment has been Successful!</div>
            <br/> AUTH CODE : " . $transResponse->getAuthCode() .  " 
            <br/>TRANS ID  : " . $transResponse->getTransId() . "\n"; 

        } else {
            $authCode = "";
            $paymentResponse = $transResponse->getErrors()[0]->getErrorText();
            $reponseType = "failed";
            $message = "<div class='alert alert-danger'>Credit Card ERROR :  Invalid response</div>";
        }
        
        $transactionId = $transResponse->getTransId();
        $responseCode = $transResponse->getResponseCode();
        $paymentStatus = $response->getMessages()->getResultCode(); 

        // Insert tansaction data into the database 
        $time = time();
        $payObj->setFirstName($postData["first_name"]);
        $payObj->setLastName($postData["last_name"]);
        $payObj->setEmail($postData["email"]);
        $payObj->setTransactionID($transactionId);
        $payObj->setAuthCode($authCode);
        $payObj->setResponseCode($responseCode);
        $payObj->setPaymentResponse($paymentResponse);
        $payObj->setTotalAmt($postData["amount"]);
        $payObj->setModifiedDate($time);
        $payObj->setCreatedDate($time);
        $payObj->setStatus($paymentStatus);
        $studentInfo = $payObj->Orders();

    } else {
        $reponseType = "error";
        $message = "<div class='alert alert-danger'>Transaction Failed! No response returned</div>";
    } 
}
?>
<!-- <?php include('templates/header.php');?>
<section class="showcase">
   <div class="container">
    <div class="text-center">
      <h1 class="display-3">Thank You!</h1>
      <?php if(!empty($message)) { ?>
        <h5><?php print $message;?></h5>
      <?php } ?>
      <hr>
      <p>
        Having trouble? <a href="mailto:info@revolus.com">Contact us</a>
      </p>
      <p class="lead">
        <a class="btn btn-primary btn-sm" href="http://localhost/ta/authorize-net-payment-gateway-integration-in-php" role="button">Continue to homepage</a>
      </p>
    </div>
    </div>
</section>
<br><br><br><br><br><br>
<?php include('templates/footer.php');?> -->