<?php 
define('ANET_API_LOGIN_ID', '3823bPwPCCC');  
define('ANET_TRANSACTION_KEY', '525vv499AkE3uAXg');    
define('ANET_ENV', 'SANDBOX'); // {OR} PRODUCTION 
?>
