<?php
/**
 * @package Order class
 *
 * @author TechArise Team
 *
 * @email  info@techarise.com
 *   
 */
include("DBConnection.php");
class Order 
{
    protected $db;
    private $_firstName;
    private $_lastName;
    private $_email;
    private $_transactionID;
    private $_authCode;
    private $_responseCode;
    private $_paymentResponse;
    private $_totalAmt;
    private $_modifiedDate;
    private $_createdDate;
    private $_status;

    public function setFirstName($firstName) {
        $this->_firstName = $firstName;
    }
    public function setLastName($lastName) {
        $this->_lastName = $lastName;
    }
    public function setEmail($email) {
        $this->_email = $email;
    }
    public function setTransactionID($transactionID) {
        $this->_transactionID = $transactionID;
    }
    public function setAuthCode($authCode) {
        $this->_authCode = $authCode;
    }
    public function setResponseCode($responseCode) {
        $this->_responseCode = $responseCode;
    }
    public function setPaymentResponse($paymentResponse) {
        $this->_paymentResponse = $paymentResponse;
    }
    public function setTotalAmt($totalAmt) {
        $this->_totalAmt = $totalAmt;
    }
    public function setModifiedDate($modifiedDate) {
        $this->_modifiedDate = $modifiedDate;
    }
    public function setCreatedDate($createdDate) {
        $this->_createdDate = $createdDate;
    }
    public function setStatus($status) {
        $this->_status = $status;
    }

    // __construct
    public function __construct() {
        $this->db = new DBConnection();
        $this->db = $this->db->returnConnection();
    }

    // insert payment info
    public function Orders() {
		try {
    		$sql = 'INSERT INTO anet_payment (first_name, last_name, email, transaction_id, auth_code, response_code, payment_response, total_amt, modified_date, created_date, status)  VALUES (:first_name, :last_name, :email, :transaction_id, :auth_code, :response_code, :payment_response, :total_amt, :modified_date, :created_date, :status)';
    		$data = [
                'first_name' => $this->_firstName,
                'last_name' => $this->_lastName,
                'email' => $this->_email,    
			    'transaction_id' => $this->_transactionID,
			    'auth_code' => $this->_authCode,
			    'response_code' => $this->_responseCode,
			    'payment_response' => $this->_paymentResponse,
			    'total_amt' => $this->_totalAmt,
			    'modified_date' => $this->_modifiedDate,
                'created_date' => $this->_createdDate,
			    'status' => $this->_status,
			];

	    	$stmt = $this->db->prepare($sql);
	    	$stmt->execute($data);
			$status = $stmt->rowCount();
            return $status;

		} catch (Exception $e) {
    		die("Oh noes! There's an error in the query!". $e);
		}

    }
}
?>