#!/bin/bash

echo "Restoring composer.json"

mv composer.json.backup composer.json

echo "SDK Generation Finished : `date`"
